package com.example.lucastheodoroo.model.dao;

import com.example.lucastheodoroo.model.entities.Veiculo;
import com.example.lucastheodoroo.model.jdbc.MinhaConexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VeiculoDAO {


    Connection con;

    public VeiculoDAO() {
        con = MinhaConexao.conexao();
    }

    public List<Veiculo> buscarVeiculos() {
        try {
            String sql = "select * from veiculo";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Veiculo> veiculos = new ArrayList<>();

            while (rs.next()) {
                Veiculo v = new Veiculo();
                v.setId(rs.getLong("id"));
                v.setMarca(rs.getString("marca"));
                v.setModelo(rs.getString("modelo"));
                v.setAnoFabricacao(rs.getInt("ano_fabricacao"));
                v.setPreco(rs.getBigDecimal("preco"));
                veiculos.add(v);
            }
            return veiculos;
        } catch (SQLException ex) {
            Logger.getLogger(VeiculoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public boolean remove(Long id) {
        try {
            String sql = "delete from veiculo where id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setLong(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException ex) {
            Logger.getLogger(VeiculoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean save(Veiculo veiculo) {
        try {
            String sql = "insert into veiculo (marca, modelo, ano_fabricacao, preco) values (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, veiculo.getMarca());
            ps.setString(2, veiculo.getModelo()); // Novo campo
            ps.setInt(3, veiculo.getAnoFabricacao()); // Novo campo
            ps.setBigDecimal(4, veiculo.getPreco()); // Novo campo

            return ps.executeUpdate() == 1;
        } catch (SQLException ex) {
            Logger.getLogger(VeiculoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean update(Veiculo veiculo) {
        try {
            String sql = "update veiculo set marca=?, modelo=?, ano_fabricacao=?, preco=? where id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, veiculo.getMarca());
            ps.setString(2, veiculo.getModelo());
            ps.setInt(3, veiculo.getAnoFabricacao());
            ps.setBigDecimal(4, veiculo.getPreco());
            ps.setLong(5, veiculo.getId());

            return ps.executeUpdate() == 1;
        } catch (SQLException ex) {
            Logger.getLogger(VeiculoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public Veiculo buscarVeiculo(Long id) {
        try {
            String sql = "select * from veiculo where id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Veiculo v = new Veiculo();
                v.setId(rs.getLong("id"));
                v.setMarca(rs.getString("marca"));
                v.setModelo(rs.getString("modelo"));
                v.setAnoFabricacao(rs.getInt("ano_fabricacao"));
                v.setPreco(rs.getBigDecimal("preco"));
                return v;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VeiculoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
