package com.example.lucastheodoroo.model.jdbc;

import java.sql.Connection;

public interface ConexaoJDBC{

    public Connection criarConexao();

}