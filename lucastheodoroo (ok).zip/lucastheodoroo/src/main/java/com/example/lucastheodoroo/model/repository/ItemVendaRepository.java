package com.example.lucastheodoroo.model.repository;

import com.example.lucastheodoroo.model.entities.ItemVenda;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public class ItemVendaRepository {
    @PersistenceContext
    private EntityManager em;

    public void salvar(ItemVenda itemVenda) {
        em.persist(itemVenda);
    }

    public ItemVenda itemVenda(Long id) {
        return em.find(ItemVenda.class, id);
    }


    public List<ItemVenda> itemVendas() {
        Query query = em.createQuery("FROM ItemVenda ");
        return query.getResultList();
    }

}
