package com.example.lucastheodoroo.model.repository;

import com.example.lucastheodoroo.model.entities.Produto;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class ProdutoRepository {

    @PersistenceContext
    private EntityManager em;


    public List<Produto> produtos() {
        TypedQuery<Produto> query = em.createQuery("FROM Produto", Produto.class);
        return query.getResultList();
    }

    public Produto procurarId(Long id) {
        return em.find(Produto.class, id);
    }
}