package com.example.lucastheodoroo.model.repository;


import com.example.lucastheodoroo.model.entities.Venda;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public class VendaRepository {

    @PersistenceContext
    private EntityManager em;

    public void salvar(Venda venda) {
        em.persist(venda);
    }

    public Venda venda(Long id) {
        return em.find(Venda.class, id);
    }


    public List<Venda> vendas() {
        Query query = em.createQuery("FROM Venda ");
        return query.getResultList();
    }

}



