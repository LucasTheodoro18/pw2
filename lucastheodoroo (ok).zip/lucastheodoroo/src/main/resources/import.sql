INSERT INTO Produto (descricao, valor) VALUES ('Produto A', 10.00);
INSERT INTO Produto (descricao, valor) VALUES ('Produto B', 20.00);

INSERT INTO Venda (data) VALUES ('2024-11-08T10:00:00');
INSERT INTO Venda (data) VALUES ('2024-11-08T11:00:00');

INSERT INTO ItemVenda (quantidade, produto_id, venda_id) VALUES (2, 1, 1);
INSERT INTO ItemVenda (quantidade, produto_id, venda_id) VALUES (1, 2, 1);
INSERT INTO ItemVenda (quantidade, produto_id, venda_id) VALUES (3, 1, 2);
