package com.example.lucastheodoroo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LucastheodorooApplicationTests {

	@Test
	void contextLoads() {
	}

}
